
abcisse = 0; //Valeur par d�faut si le hasard ne fonctionn pas
ordonnee = 0
abcissePrecedent , ordonneePrecedent;
		bool alive;