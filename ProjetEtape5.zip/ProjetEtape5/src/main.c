/**
  ******************************************************************************************************************
  * @file    main.c 
  * @author  Alfred.G     IUT Informatique La Rochelle
  * @version v5
  * @date    16 Juin 2018
  * @brief   Projet Space Invader
  ******************************************************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <stm32f10x.h> // STM32F10x Library Definitions
#include "stm32f10x.h"                  /* STM32F10x.h definitions            */
#include "GLCD_Config.h"
#include "boule.h"
#include "ext_globales.h"
#include "globales.h"
#include "ennemi.c"
#include <math.h>

#define UIE (1<<0) 
#define UIF (1<<0) //Flag d'interruption
#define ENNEMIS 15

int compteur[6]={0 , 0 , 0 , 0 , 0 , 0}; //Un compteur, �a peut toujours �tre utile
int diviseur[4] = {0 , 0 , 0 , 0};

/*----------------------------------------------------------------------------
  	D�claration boutons
*----------------------------------------------------------------------------*/
unsigned long bouton_WAKEUP; //WAKEUP
unsigned long bouton_TEMPER; //TAMPER
unsigned long bouton_USER; //USER
unsigned long bouton_DOWN; //DOWN
unsigned long bouton_LEFT; //LEFT
unsigned long bouton_RIGHT; //RIGHT
unsigned long bouton_UP; //UP
bool aEteRelache[3]; //Test si le TAMPER ou WAKEUP a été relâché
#define APPUYE 0x0000
#define APPUYE_wakeup 1
#define SETENA0 *(volatile unsigned long *)0xE000E100

/*----------------------------------------------------------------------------
  Ennemis
 *----------------------------------------------------------------------------*/
struct Ennemi listeEnnemis[15]; //Nombre maximum choisi d'�nnemis pr�sents sur l'�cran

/*----------------------------------------------------------------------------
  Etats
 *----------------------------------------------------------------------------*/
enum EtatDirectionnel {UP = 0 , RIGHT = 1 , DOWN = 2 , LEFT = 3 , NONE = 6};
enum EtatAppuie {WAKEUP = 0 , TEMPER = 1 , USER = 2};
enum EtatJeu {enJeu = 0 , gameOver = 1};
enum Angle {hautGauche = 0 , hautDroit = 1 , basGauche = 2 , basDroit = 3};
int currentOrientationState , currentDirectionState , currentGameState , hazard , dernierAbs , dernierOrd;
bool premiereApparition = false , fonctionToucheExecutee = false , effacementJoueur = true;

/*----------------------------------------------------------------------------
  R�apparition Alien 
 *----------------------------------------------------------------------------*/
void calculPosEnFonctionDelAngle(int unCompteur){
	switch(listeEnnemis[unCompteur].angle){
		case hautGauche:
			listeEnnemis[unCompteur].abscisse = 0;
			listeEnnemis[unCompteur].ordonne = 10;
			break;
		case hautDroit:
			listeEnnemis[unCompteur].abscisse = 320 - LARGEUR_BOULE;
			listeEnnemis[unCompteur].ordonne = 10;
			break;
		case basGauche:
			listeEnnemis[unCompteur].abscisse = 0;
			listeEnnemis[unCompteur].ordonne = 240 - HAUTEUR_BOULE;
			break;
		case basDroit:
			listeEnnemis[unCompteur].abscisse = 320 - LARGEUR_BOULE;
			listeEnnemis[unCompteur].ordonne = 240 - HAUTEUR_BOULE;
			break;
	}
}

void naissanceAlien(void){
	int nbNaissance = 0; //
	int angleProche[2] = {0 , 0};
	double lesDistances[4];
	lesDistances[hautGauche] = sqrt(pow((0 - lAbscisse) , 2) + pow(9 - lOrdonne , 2));
	lesDistances[hautDroit] = sqrt(pow(((320 - LARGEUR_BOULE) - lAbscisse) , 2) + pow(9 - lOrdonne , 2));
	lesDistances[basGauche] = sqrt(pow((0 - lAbscisse) , 2) + pow(((240 - HAUTEUR_BOULE) - lOrdonne) , 2));
	lesDistances[basDroit] = sqrt(pow((320 - LARGEUR_BOULE) - lAbscisse , 2) + pow(((240 - HAUTEUR_BOULE) - lOrdonne) , 2));
	for (compteur[1] = 1 ; compteur[1] < 3 ; compteur[1]++){
		if (lesDistances[angleProche[0]] > lesDistances[compteur[1]]) angleProche[0] = compteur[1];
	}
	if (angleProche[0] == 0)
	{
		angleProche[1]++;
	}
	for (compteur[1] = 1 ; compteur[1] < 4 ; compteur[1]++){
		if (lesDistances[angleProche[1]] > lesDistances[compteur[1]] && compteur[1] != angleProche[0]) angleProche[1] = compteur[1];
	}
	for (compteur[1] = 0 ; compteur[1] < ENNEMIS ; compteur[1]++){
		if (nbNaissance < 2 && !listeEnnemis[compteur[1]].alive) //nbNaissance est un indice donc nbNaissance = 1 �quivaut � 2 naissances
		{
			listeEnnemis[compteur[1]].angle = angleProche[nbNaissance];
			calculPosEnFonctionDelAngle(compteur[1]);
			listeEnnemis[compteur[1]].alive = true;
			nbNaissance++;
		}
	}
}

/*----------------------------------------------------------------------------
  V�rification des conditions avant le d�placements du joueur
 *----------------------------------------------------------------------------*/
bool verificationDeplacementsJoueur(int orientation){
	switch(currentDirectionState){
		case RIGHT:
			if (bouton_USER == APPUYE || !effacementJoueur) return false;
			else if (lAbscisse == 134 && lOrdonne < 126 && lOrdonne > 94) return false;
			else if (lAbscisse != (320 - LARGEUR_BOULE)) return true;
			break;
		case LEFT:
			if (bouton_USER == APPUYE || !effacementJoueur) return false;
			else if (lAbscisse == 166 && lOrdonne < 126 && lOrdonne > 94) return false;
			if (lAbscisse != 0 && bouton_USER != APPUYE) return true;
			break;
		case UP:
			if (bouton_USER == APPUYE || !effacementJoueur) return false;
			else if (lOrdonne == 126 && lAbscisse < 166 && lAbscisse > 134) return false;
			else if (false) return false;
			if (lOrdonne != 9 && bouton_USER != APPUYE) return true;
			break;
		case DOWN:
			if (bouton_USER == APPUYE || !effacementJoueur) return false;
			else if (lOrdonne == 94 && lAbscisse < 166 && lAbscisse > 134) return false;
			if (lOrdonne != (240 - LARGEUR_BOULE) && bouton_USER != APPUYE) return true;
			break;
	}
	return false;
}

/*----------------------------------------------------------------------------
  GPIO
 *----------------------------------------------------------------------------*/
void Enable_GPIO(void){ //Mise en service
	RCC->APB2ENR |= (1<<2); //GPIOA
	RCC->APB2ENR |= (1<<4); //GPIOC
	RCC->APB2ENR |= (1<<5); //GPIOD
	RCC->APB2ENR |= (1<<8); //GPIOG
}

void Init_GPIO(void){ //Initialisation
	GPIOA->CRL = 0x00030004; //GPIOA \ WAKEUP || SON
	GPIOC->CRL = 0x00400000; //GPIOC \ TAMPER
	GPIOD->CRL = 0x00004000; //GPIOD \ DOWN
	GPIOG->CRH = 0x44400004; //GPIOG \ LEFT || RIGHT || UP || USER
}

/*----------------------------------------------------------------------------
  Timer
 *----------------------------------------------------------------------------*/
void cfgTimer1(void){
	RCC->APB2ENR |= (1 << 11);
	TIM1->PSC = 9; //On choisi un PSC � 9
	TIM1->ARR = 45000; //72/10=7.2Mhz = 7.2*10^6Hz/160 = 45000
	TIM1->DIER |= (1<<0);
	TIM1->CR1 |= 0x0001;
	SETENA0 |= (1<<25);
}

void cfgTimer2(void){
 RCC->APB1ENR |= (1 << 0);
 TIM2->PSC = 5;
 TIM2->ARR = 700; //Un ARR � 9000 sera plus approppri�, on a ici une machine � casser des oreilles
 TIM2->DIER |= UIE;
 SETENA0 |= (1<<28);
}

void cfgTimer3(void){
 RCC->APB1ENR |= (1 << 1);
 TIM3->PSC = 29;  //On choisi un PSC � 29 sinon l'arr sera trop grand
 TIM3->ARR = 60000; //72/30=2.4Mhz = 2.4*10^6Hz/40 = 60000
 TIM3->DIER |= UIE;
 TIM3->CR1 |= 0x0001;
 SETENA0 |= (1<<29);
}


/*----------------------------------------------------------------------------
  Interruptions timer
 *----------------------------------------------------------------------------*/
void TIM1_UP_TIM10_IRQHandler (void){
 	if(TIM1->SR & UIF)
 	{
	  	TIM1->SR &= ~UIF; //Abaissement du flag d'interruption
	  //DEPLACEMENTS JOUEUR
		switch(currentDirectionState){
			case RIGHT:
				if (verificationDeplacementsJoueur(RIGHT)){
					dernierAbs = lAbscisse;
					lAbscisse++;
					effacementJoueur = false;
				}
				break;
			case LEFT:
				if (verificationDeplacementsJoueur(LEFT)){
					dernierAbs = lAbscisse;
					lAbscisse--;
					effacementJoueur = false;
				}
				break;
			case UP:
				if (verificationDeplacementsJoueur(UP)){
					dernierOrd = lOrdonne;
					lOrdonne--;
					effacementJoueur = false;
				}
				break;
			case DOWN:
				if (verificationDeplacementsJoueur(DOWN)){
					dernierOrd = lOrdonne;
					lOrdonne++;
					effacementJoueur = false;
				}
				break;
		}

		//APPARITION ANGLE AU HAZARD
		if (hazard == 3)
		{
			hazard = 0;
		}else hazard++;

		if (currentDirectionState != NONE && !premiereApparition)
		{
			premiereApparition = true;
			listeEnnemis[0].angle = hazard;
			calculPosEnFonctionDelAngle(0);
			listeEnnemis[0].alive = true;
		}
	}
}

void TIM2_IRQHandler (void){
	if(TIM2->SR & UIF){
		GPIOA->ODR ^= (1<<4); // Si appui sur le boutton, la carte emet un son
		TIM2->SR &= ~UIF; // on baisse le drapeau
	}
}

void TIM3_IRQHandler (void){
	if(TIM3->SR & UIF){
		TIM3->SR &= ~UIF; // on baisse le drapeau
		//DEPLACEMENTS ENNEMIS
		for (compteur[5] = 0 ; compteur[5] < ENNEMIS ; compteur[5]++){
			if (listeEnnemis[compteur[5]].alive)
			{
				if (listeEnnemis[compteur[5]].ordonne < 110){
						listeEnnemis[compteur[5]].ordonnePrecedent = listeEnnemis[compteur[5]].ordonne;
						listeEnnemis[compteur[5]].ordonne++;
				}else if(listeEnnemis[compteur[5]].ordonne > 110){
						listeEnnemis[compteur[5]].ordonnePrecedent = listeEnnemis[compteur[5]].ordonne;
						listeEnnemis[compteur[5]].ordonne--;
				}else if (listeEnnemis[compteur[5]].ordonne == 110){
					if (listeEnnemis[compteur[5]].abscisse < 134){
							listeEnnemis[compteur[5]].abcissePrecedent = listeEnnemis[compteur[5]].abscisse;
							listeEnnemis[compteur[5]].abscisse++;
					}else if(listeEnnemis[compteur[5]].abscisse > 134){
							listeEnnemis[compteur[5]].abcissePrecedent = listeEnnemis[compteur[5]].abscisse;
							listeEnnemis[compteur[5]].abscisse--;
					}
				}
			}
		}
	}
}

/*----------------------------------------------------------------------------
  Coordonn�es en commun (collision avec l'énnemi)
 *----------------------------------------------------------------------------*/
bool positionCommune(int unCompteur){
	for (compteur[1] = 0; compteur[1] < 16 ; compteur[1]++){
		for (compteur[2] = 0; compteur[2] < 16 ; compteur[2]++){
			if (listeEnnemis[unCompteur].abscisse + compteur[1] == lAbscisse + compteur[2]){
				for (compteur[3] = 0; compteur[3] < 16 ; compteur[3]++){
					for (compteur[4] = 0; compteur[4] < 16; compteur[4]++){
						if (listeEnnemis[unCompteur].ordonne + compteur[3] == lOrdonne + compteur[4]) return true;
					}
				}
			}
		}
	}
	return false;
}

/*----------------------------------------------------------------------------
  A t'on touch� un �nnemi ? TRUE FALSE
 *----------------------------------------------------------------------------*/
bool touche(int unCompteur){
	switch(currentOrientationState){
		case RIGHT:
			if ((listeEnnemis[unCompteur].abscisse + LARGEUR_BOULE) > lAbscisse){
					if ((lOrdonne + 8 <= listeEnnemis[unCompteur].ordonne + 16 && lOrdonne + 8 >= listeEnnemis[unCompteur].ordonne)) return true;
			}
			break;
		case LEFT:
			if ((listeEnnemis[unCompteur].abscisse + 16) < lAbscisse){
				for (compteur[1] = 0; compteur[1] < 16 ; compteur[1]++){
					if (listeEnnemis[unCompteur].ordonne + 8 == lOrdonne + compteur[1]) return true;
				}
			}
			break;
		case UP:
			if (listeEnnemis[unCompteur].ordonne < lOrdonne + 16){
				for (compteur[1] = 0; compteur[1] < 16 ; compteur[1]++){
					if (listeEnnemis[unCompteur].abscisse + 8 == lAbscisse + compteur[1]) return true;
				}
			}
			break;
		case DOWN:
			if (listeEnnemis[unCompteur].ordonne > lOrdonne + HAUTEUR_BOULE){
				for (compteur[1] = 0; compteur[1] < 16 ; compteur[1]++){
					if (listeEnnemis[unCompteur].abscisse + 8 == lAbscisse + compteur[1]) return true;
				}
			}
			break;
	}
	return false;
}

/*----------------------------------------------------------------------------
  Coordonn�es touch�s pour la r�serve !
 *----------------------------------------------------------------------------*/
bool toucheReserve(){
	switch(currentOrientationState){
		case RIGHT:
			if (150 >= lAbscisse && lOrdonne + 8 <= 110 + 16 && lOrdonne + 8 >= 110) return true;
				/*for (compteur[1] = 0; compteur[1] < 16 ; compteur[1]++)
				{
					if (110 + 8 == lOrdonne + compteur[1])
					{
						return true;
					}
				}*/
			break;
		case LEFT:
			if (166 <= lAbscisse && lOrdonne + 8 <= 110 + 16 && lOrdonne + 8 >= 110) return true;
				/*for (compteur[1] = 0; compteur[1] < 16 ; compteur[1]++)
				{
					if (110 + 8 == lOrdonne + compteur[1])
					{
						return true;
					}
				}*/
			break;
		case UP:
			if (110 < lOrdonne && lAbscisse + 8 <= 150 + 16 && lAbscisse + 8 >= 150) return true;
				/*for (compteur[1] = 0; compteur[1] < 16 ; compteur[1]++)
				{
					if (150 + 8 == lAbscisse + compteur[1])
					{
						return true;
					}
				}*/
			break;
		case DOWN:
			if (110 > lOrdonne && lAbscisse + 8 <= 150 + 16 && lAbscisse + 8 >= 150) return true;
				/*for (compteur[1] = 0; compteur[1] < 16 ; compteur[1]++)
				{
					if (150 + 8 == lAbscisse + compteur[1])
					{
						return true;
					}
				}*/
			break;
	}
	return false;
}

/*----------------------------------------------------------------------------
  Effacement des traces de d�placements de l'�nnemi
 *----------------------------------------------------------------------------*/
void effacementEnnemi(void){
//Effacement derri�re l'�nnemi lorsqu'il se d�place en abcisse
	if(listeEnnemis[compteur[0]].abscisse > listeEnnemis[compteur[0]].abcissePrecedent){
		GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
		GLCD_DrawVLine(listeEnnemis[compteur[0]].abscisse - 1 , listeEnnemis[compteur[0]].ordonne , 16);
	}else if(listeEnnemis[compteur[0]].abscisse < listeEnnemis[compteur[0]].abcissePrecedent){
		GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
		GLCD_DrawVLine((listeEnnemis[compteur[0]].abscisse + 16) , listeEnnemis[compteur[0]].ordonne , 16);
	}
	//Effacement derri�re l'ennemi lorsqu'il se d�place en ordonne
	if(listeEnnemis[compteur[0]].ordonne > listeEnnemis[compteur[0]].ordonnePrecedent){
		GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
		GLCD_DrawHLine(listeEnnemis[compteur[0]].abscisse , (listeEnnemis[compteur[0]].ordonne - 1) , 16);
	}else if(listeEnnemis[compteur[0]].ordonne < listeEnnemis[compteur[0]].ordonnePrecedent){
		GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
		GLCD_DrawHLine(listeEnnemis[compteur[0]].abscisse , (listeEnnemis[compteur[0]].ordonne + 16) , 16);
	}
}

/*----------------------------------------------------------------------------
  Gestion des �v�nements si on a touch� un �l�ment avec le laser
 *----------------------------------------------------------------------------*/
void touchePrincipal(void) {
	if (toucheReserve()){
		GLCD_SetForegroundColor(GLCD_COLOR_WHITE);
		GLCD_DrawString(30 , 110 , "touche Reserve");
	}
	for (compteur[0] = 0; compteur[0] < ENNEMIS; compteur[0]++){
		if(listeEnnemis[compteur[0]].alive && touche(compteur[0])){
			listeEnnemis[compteur[0]].alive = false;
			effacementEnnemi();
			GLCD_DrawBitmap(listeEnnemis[compteur[0]].abscisse , listeEnnemis[compteur[0]].ordonne , 16 , 16 , (const unsigned char *)noir);
			listeEnnemis[compteur[0]].ordonne = 0;
			listeEnnemis[compteur[0]].abscisse = 0;
			fonctionToucheExecutee = true;
			naissanceAlien();
		}
	}
}

/*----------------------------------------------------------------------------
  Main Program
 *----------------------------------------------------------------------------*/
int main (void){
	int abcTire , ordTire , longTire; //D�clarations var m�moire coordonn�es
	bool lazerEfface[4];
	effacementJoueur = true;
	currentOrientationState = UP; //D�finition var orientation
	currentDirectionState = NONE; //D�finition var direction
	abcTire = 0; //VALEUR PAR DEFAUT
	ordTire = 0; //VALEUR PAR DEFAUT
	longTire = 0; //VALEUR PAR DEFAUT
	Enable_GPIO();
	Init_GPIO();
	dernierAbs = lAbscisse;
	dernierOrd = lOrdonne;
	lOrdonne = 240 - HAUTEUR_BOULE;
	lAbscisse = 150;
	GLCD_Initialize();                          /* Initialize graphical LCD display   */
 	GLCD_SetBackgroundColor(GLCD_COLOR_BLACK);
	GLCD_SetForegroundColor(GLCD_COLOR_RED);
	GLCD_ClearScreen();               /* Clear graphical LCD display        */
	GLCD_SetFont(&GLCD_Font_6x8);
	GLCD_FrameBufferAccess(true); // A faire avant appel de GLCD_DrawPixel et GLCD_ReadPixel pour supprimer
																// les limitations d'accès à la SRAM (uniquement nécessaire sur les anciennes
																// cartes sinon les fonctions GLCD_DrawPixel et GLCD_ReadPixel ne 
																// fonctionnent pas
	GLCD_DrawString(30 , 0 , "Projet Si - Alfred Gaillard | D2");
	GLCD_DrawHLine(0 , 8 , 320);
	GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
	
	for (compteur[0] = 1 ; compteur[0] < ENNEMIS ; compteur[0]++){
		listeEnnemis[compteur[0]].alive = false;
		listeEnnemis[compteur[0]].abscisse = 0;
		listeEnnemis[compteur[0]].ordonne = 10;
		listeEnnemis[compteur[0]].abcissePrecedent = 0;
		listeEnnemis[compteur[0]].ordonnePrecedent = 10;
	}
	
	cfgTimer1();
	cfgTimer2();
	cfgTimer3();
	
	for (compteur[0] = 0 ; compteur[0] != 3 ; compteur[0]++) aEteRelache[compteur[0]] = true; //Boutons sont tous relache par defaut
	for (compteur[0] = 0 ; compteur[0] != 4 ; compteur[0]++) lazerEfface[compteur[0]] = true; //Lazer pas encore trac�s donc nul besoin de les effacer
	currentOrientationState = UP; //D�finition var orientation

	while(1){
	/*----------------------------------------------------------------------------
  	D�finition de l'idr (input) des boutons
 	*----------------------------------------------------------------------------*/
		bouton_WAKEUP = GPIOA->IDR & 0x0001;
		bouton_TEMPER = GPIOC->IDR & 0x2000;
		bouton_USER = GPIOG->IDR & 0x0100;
		bouton_DOWN = GPIOD->IDR & 0x0008;
		bouton_LEFT = GPIOG->IDR & 0x4000;
		bouton_RIGHT = GPIOG->IDR & 0x2000;
		bouton_UP = GPIOG->IDR & 0x8000;

		//USER
		switch(currentOrientationState){
			case RIGHT:
				if(bouton_USER != APPUYE){
					aEteRelache[USER] = true;
					fonctionToucheExecutee = false;
					if (!lazerEfface[currentOrientationState]){
						GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
						GLCD_DrawHLine(abcTire , ordTire , longTire);
						lazerEfface[currentOrientationState] = true;
					}
				}else if (aEteRelache[USER]){
					abcTire = lAbscisse + LARGEUR_BOULE;
					ordTire = lOrdonne + (HAUTEUR_BOULE/2) - 1;
					longTire = 320 - lAbscisse + LARGEUR_BOULE;
					GLCD_SetForegroundColor(GLCD_COLOR_BLUE);
					GLCD_DrawHLine(abcTire , ordTire , longTire);
					lazerEfface[currentOrientationState] = false;
				}
				if(bouton_USER == APPUYE ){
					TIM2->CR1 |= 0x0001; //SON
					if (!fonctionToucheExecutee) touchePrincipal();
				}else TIM2->CR1 &= 0x0000; //SON
				break;
			case LEFT:
				if(bouton_USER != APPUYE){
					aEteRelache[USER] = true;
					fonctionToucheExecutee = false;
					if (!lazerEfface[currentOrientationState]){
						GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
						GLCD_DrawHLine(abcTire , ordTire , longTire);
						lazerEfface[currentOrientationState] = true;
					}
				}else if (aEteRelache[USER]){
					abcTire = 0;
					ordTire = lOrdonne + (HAUTEUR_BOULE/2) - 1;
					longTire = lAbscisse;
					GLCD_SetForegroundColor(GLCD_COLOR_BLUE);
					GLCD_DrawHLine(abcTire , ordTire , longTire);
					lazerEfface[currentOrientationState] = false;
				}
				if(bouton_USER == APPUYE ){
					TIM2->CR1 |= 0x0001; //SON
					if (!fonctionToucheExecutee) touchePrincipal();
				}else TIM2->CR1 &= 0x0000; //SON
				break;
			case UP:
				if(bouton_USER != APPUYE){
					aEteRelache[USER] = true;
					fonctionToucheExecutee = false;
					if (!lazerEfface[currentOrientationState]){
						GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
						GLCD_DrawVLine(abcTire , ordTire , longTire);
						lazerEfface[currentOrientationState] = true;
					}
				}else if (aEteRelache[USER]){
					abcTire = lAbscisse + (LARGEUR_BOULE/2) - 1;
					ordTire = 9;
					longTire = lOrdonne - (HAUTEUR_BOULE/2);
					GLCD_SetForegroundColor(GLCD_COLOR_BLUE);
					GLCD_DrawVLine(abcTire , ordTire , longTire);
					lazerEfface[currentOrientationState] = false;
				}
				if(bouton_USER == APPUYE ){
					TIM2->CR1 |= 0x0001; //SON
					if (!fonctionToucheExecutee) touchePrincipal();
				}else TIM2->CR1 &= 0x0000; //SON
				break;
			case DOWN:
				if(bouton_USER != APPUYE){
					aEteRelache[USER] = true;
					fonctionToucheExecutee = false;
					if (!lazerEfface[currentOrientationState]){
						GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
						GLCD_DrawVLine(abcTire , ordTire , longTire);
						lazerEfface[currentOrientationState] = true;
					}
				}else if (aEteRelache[USER]){
					abcTire = lAbscisse + (LARGEUR_BOULE/2) - 1;
					ordTire = lOrdonne + HAUTEUR_BOULE;
					longTire = 240 - (lOrdonne + HAUTEUR_BOULE);
					GLCD_SetForegroundColor(GLCD_COLOR_BLUE);
					GLCD_DrawVLine(abcTire , ordTire , longTire);
					lazerEfface[currentOrientationState] = false;
				}
				if(bouton_USER == APPUYE ){
					TIM2->CR1 |= 0x0001; //SON
					if (!fonctionToucheExecutee) touchePrincipal();
				}else TIM2->CR1 &= 0x0000; //SON
				break;
		}
			 /*if(touche(currentOrientationState , lAbscisse , lOrdonne , listeEnnemis[compteur[0]])){
						GLCD_SetForegroundColor(GLCD_COLOR_WHITE);
						GLCD_DrawString(30 , 110 , "touche");
				}
				if ((lOrdonne + 8 <= listeEnnemis[0].ordonne + 16 && lOrdonne + 8 >= listeEnnemis[0].ordonne))
					{
						GLCD_SetForegroundColor(GLCD_COLOR_WHITE);
						GLCD_DrawString(30 , 110 , "touche");
					}*/
		
		
		//NONE
		if (bouton_DOWN != APPUYE && bouton_UP != APPUYE && bouton_LEFT != APPUYE && bouton_RIGHT != APPUYE){
			currentDirectionState = NONE;
			effacementJoueur = true;
		}

		//DOWN
		else if (bouton_DOWN == APPUYE) currentDirectionState = DOWN;

		//UP
		else if (bouton_UP == APPUYE) currentDirectionState = UP;

		//LEFT
		else if (bouton_LEFT == APPUYE) currentDirectionState = LEFT;

		//RIGHT
		else if (bouton_RIGHT == APPUYE) currentDirectionState = RIGHT;
		
		//WAKEUP
		if (bouton_WAKEUP != APPUYE_wakeup) aEteRelache[WAKEUP] = true; //VALEUR D'APPUYE INVERSE POUR WAKEUP
		else if (aEteRelache[WAKEUP] && bouton_USER != APPUYE){
			currentOrientationState++;
			aEteRelache[WAKEUP] = false;
			if(currentOrientationState > 3) currentOrientationState = 0; //Retour pos0 si tour complet effectu�
		}

		//TEMPER
		if (bouton_TEMPER != APPUYE) aEteRelache[TEMPER] = true;
		else if(aEteRelache[TEMPER] && bouton_USER != APPUYE){
			currentOrientationState--;
			aEteRelache[TEMPER] = false;
			if(currentOrientationState < 0) currentOrientationState = 3; //Retour pos3 si on part de pos0
		}
		
		for (compteur[0] = 0 ; compteur[0] < ENNEMIS ; compteur[0]++)
		{ 
			if (listeEnnemis[compteur[0]].alive)
			{
				GLCD_DrawBitmap(listeEnnemis[compteur[0]].abscisse , listeEnnemis[compteur[0]].ordonne , 16 , 16 , (const unsigned char *)ennemi);
			}
		}

		GLCD_DrawBitmap(150 , 110 , 16 , 16 , (const unsigned char *)reserve);
		GLCD_DrawBitmap(lAbscisse , lOrdonne , LARGEUR_BOULE , HAUTEUR_BOULE , (const unsigned char *)vaisseau[currentOrientationState]);
		
		//Effacement derri�re le vaisseau lorsqu'il se d�place en abcisse
		if(lAbscisse > dernierAbs){
			GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
			GLCD_DrawVLine(lAbscisse - 1 , lOrdonne , HAUTEUR_BOULE);
			effacementJoueur = true;
		}else if(lAbscisse < dernierAbs){
			GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
			GLCD_DrawVLine((lAbscisse + LARGEUR_BOULE) , lOrdonne , HAUTEUR_BOULE);
			effacementJoueur = true;
		}

		//Effacement derri�re le vaisseau lorsqu'il se d�place en ordonne
		if(lOrdonne > dernierOrd){
			GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
			GLCD_DrawHLine(lAbscisse , (lOrdonne - 1) , HAUTEUR_BOULE);
			effacementJoueur = true;
		}else if(lOrdonne < dernierOrd){
			GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
			GLCD_DrawHLine(lAbscisse , (lOrdonne + HAUTEUR_BOULE) , HAUTEUR_BOULE);
			effacementJoueur = true;
		}
		
		for (compteur[0] = 0 ; compteur[0] < ENNEMIS ; compteur[0]++){
			if (listeEnnemis[compteur[0]].alive){
				effacementEnnemi();
				if (positionCommune(compteur[0]))//Si un monstre touche le joueur
				{
					GLCD_SetForegroundColor(GLCD_COLOR_WHITE);
					GLCD_DrawString(30 , 110 , "Collision");
					currentGameState = gameOver;
				}

			}
		}
	}
}
