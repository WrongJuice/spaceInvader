/**
  ******************************************************************************************************************
  * @file    main.c 
  * @author  Alfred.G     IUT Informatique La Rochelle
  * @version v5
  * @date    16 Juin 2018
  * @brief   Projet Space Invader
  ******************************************************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <stm32f10x.h> // STM32F10x Library Definitions
#include "stm32f10x.h"                  /* STM32F10x.h definitions            */
#include "GLCD_Config.h"
#include "boule.h"
#include "ext_globales.h"
#include "globales.h"
#include <math.h>

#define UIE (1<<0) 
#define UIF (1<<0) //Flag d'interruption

int compteur[6]={0 , 0 , 0 , 0 , 0 , 0}; //Un compteur, �a peut toujours �tre utile

/*----------------------------------------------------------------------------
  	D�claration boutons
*----------------------------------------------------------------------------*/
unsigned long bouton_WAKEUP; //WAKEUP
unsigned long bouton_TEMPER; //TAMPER
unsigned long bouton_DOWN; //DOWN
unsigned long bouton_LEFT; //LEFT
unsigned long bouton_RIGHT; //RIGHT
unsigned long bouton_UP; //UP
bool aEteRelache[3]; //Test si le TAMPER ou WAKEUP a été relâché
#define APPUYE 0x0000
#define APPUYE_wakeup 1
#define SETENA0 *(volatile unsigned long *)0xE000E100

/*----------------------------------------------------------------------------
  Etats
 *----------------------------------------------------------------------------*/
enum EtatDirectionnel {UP = 0 , RIGHT = 1 , DOWN = 2 , LEFT = 3 , NONE = 6};
enum EtatAppuie {WAKEUP = 0 , TEMPER = 1};
int currentOrientationState , currentDirectionState , dernierAbs , dernierOrd;
bool effacementJoueur = true;

/*----------------------------------------------------------------------------
  V�rification des conditions avant le d�placements du joueur
 *----------------------------------------------------------------------------*/
bool verificationDeplacementsJoueur(int orientation){
	switch(currentDirectionState){
		case RIGHT:
			if (!effacementJoueur) return false;
			else if (lAbscisse != (320 - LARGEUR_BOULE)) return true;
			break;
		case LEFT:
			if (!effacementJoueur) return false;
			else if (lAbscisse != 0) return true;
			break;
		case UP:
			if (!effacementJoueur) return false;
			else if (false) return false;
			if (lOrdonne != 9) return true;
			break;
		case DOWN:
			if (!effacementJoueur) return false;
			else if (lOrdonne != (240 - LARGEUR_BOULE)) return true;
			break;
	}
	return false;
}

/*----------------------------------------------------------------------------
  GPIO
 *----------------------------------------------------------------------------*/
void Enable_GPIO(void){ //Mise en service
	RCC->APB2ENR |= (1<<2); //GPIOA
	RCC->APB2ENR |= (1<<4); //GPIOC
	RCC->APB2ENR |= (1<<5); //GPIOD
	RCC->APB2ENR |= (1<<8); //GPIOG
}

void Init_GPIO(void){ //Initialisation
	GPIOA->CRL = 0x00030004; //GPIOA \ WAKEUP || SON
	GPIOC->CRL = 0x00400000; //GPIOC \ TAMPER
	GPIOD->CRL = 0x00004000; //GPIOD \ DOWN
	GPIOG->CRH = 0x44400004; //GPIOG \ LEFT || RIGHT || UP || USER
}

/*----------------------------------------------------------------------------
  Timer
 *----------------------------------------------------------------------------*/
void cfgTimer1(void){
	RCC->APB2ENR |= (1 << 11);
	TIM1->PSC = 9; //On choisi un PSC � 9
	TIM1->ARR = 45000; //72/10=7.2Mhz = 7.2*10^6Hz/160 = 45000
	TIM1->DIER |= (1<<0);
	TIM1->CR1 |= 0x0001;
	SETENA0 |= (1<<25);
}


/*----------------------------------------------------------------------------
  Interruptions timer
 *----------------------------------------------------------------------------*/
void TIM1_UP_TIM10_IRQHandler (void){
 	if(TIM1->SR & UIF)
 	{
	  	TIM1->SR &= ~UIF; //Abaissement du flag d'interruption
	  //DEPLACEMENTS JOUEUR
		switch(currentDirectionState){
			case RIGHT:
				if (verificationDeplacementsJoueur(RIGHT)){
					dernierAbs = lAbscisse;
					lAbscisse++;
					effacementJoueur = false;
				}
				break;
			case LEFT:
				if (verificationDeplacementsJoueur(LEFT)){
					dernierAbs = lAbscisse;
					lAbscisse--;
					effacementJoueur = false;
				}
				break;
			case UP:
				if (verificationDeplacementsJoueur(UP)){
					dernierOrd = lOrdonne;
					lOrdonne--;
					effacementJoueur = false;
				}
				break;
			case DOWN:
				if (verificationDeplacementsJoueur(DOWN)){
					dernierOrd = lOrdonne;
					lOrdonne++;
					effacementJoueur = false;
				}
				break;
		}

		
	}
}

/*----------------------------------------------------------------------------
  Main Program
 *----------------------------------------------------------------------------*/
int main (void){
	effacementJoueur = true;
	currentOrientationState = UP; //D�finition var orientation
	currentDirectionState = NONE; //D�finition var direction
	Enable_GPIO();
	Init_GPIO();
	dernierAbs = lAbscisse;
	dernierOrd = lOrdonne;
	lOrdonne = 240 - HAUTEUR_BOULE;
	lAbscisse = 150;
	GLCD_Initialize();                          /* Initialize graphical LCD display   */
 	GLCD_SetBackgroundColor(GLCD_COLOR_BLACK);
	GLCD_SetForegroundColor(GLCD_COLOR_RED);
	GLCD_ClearScreen();               /* Clear graphical LCD display        */
	GLCD_SetFont(&GLCD_Font_6x8);
	GLCD_FrameBufferAccess(true); // A faire avant appel de GLCD_DrawPixel et GLCD_ReadPixel pour supprimer
																// les limitations d'accès à la SRAM (uniquement nécessaire sur les anciennes
																// cartes sinon les fonctions GLCD_DrawPixel et GLCD_ReadPixel ne 
																// fonctionnent pas
	GLCD_DrawString(30 , 0 , "Projet Si - Alfred Gaillard | D2");
	GLCD_DrawHLine(0 , 8 , 320);
	GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
	
	
	cfgTimer1();
	
	for (compteur[0] = 0 ; compteur[0] != 3 ; compteur[0]++) aEteRelache[compteur[0]] = true; //Boutons sont tous relache par defaut
	currentOrientationState = UP; //D�finition var orientation

	while(1){
	/*----------------------------------------------------------------------------
  	D�finition de l'idr (input) des boutons
 	*----------------------------------------------------------------------------*/
		bouton_WAKEUP = GPIOA->IDR & 0x0001;
		bouton_TEMPER = GPIOC->IDR & 0x2000;
		bouton_DOWN = GPIOD->IDR & 0x0008;
		bouton_LEFT = GPIOG->IDR & 0x4000;
		bouton_RIGHT = GPIOG->IDR & 0x2000;
		bouton_UP = GPIOG->IDR & 0x8000;

		
		//NONE
		if (bouton_DOWN != APPUYE && bouton_UP != APPUYE && bouton_LEFT != APPUYE && bouton_RIGHT != APPUYE){
			currentDirectionState = NONE;
			effacementJoueur = true;
		}

		//DOWN
		else if (bouton_DOWN == APPUYE) currentDirectionState = DOWN;

		//UP
		else if (bouton_UP == APPUYE) currentDirectionState = UP;

		//LEFT
		else if (bouton_LEFT == APPUYE) currentDirectionState = LEFT;

		//RIGHT
		else if (bouton_RIGHT == APPUYE) currentDirectionState = RIGHT;
		
		//WAKEUP
		if (bouton_WAKEUP != APPUYE_wakeup) aEteRelache[WAKEUP] = true; //VALEUR D'APPUYE INVERSE POUR WAKEUP
		else if (aEteRelache[WAKEUP]){
			currentOrientationState++;
			aEteRelache[WAKEUP] = false;
			if(currentOrientationState > 3) currentOrientationState = 0; //Retour pos0 si tour complet effectu�
		}

		//TEMPER
		if (bouton_TEMPER != APPUYE) aEteRelache[TEMPER] = true;
		else if(aEteRelache[TEMPER]){
			currentOrientationState--;
			aEteRelache[TEMPER] = false;
			if(currentOrientationState < 0) currentOrientationState = 3; //Retour pos3 si on part de pos0
		}
		
		GLCD_DrawBitmap(lAbscisse , lOrdonne , LARGEUR_BOULE , HAUTEUR_BOULE , (const unsigned char *)vaisseau[currentOrientationState]);
		
		//Effacement derri�re le vaisseau lorsqu'il se d�place en abcisse
		if(lAbscisse > dernierAbs){
			GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
			GLCD_DrawVLine(lAbscisse - 1 , lOrdonne , HAUTEUR_BOULE);
			effacementJoueur = true;
		}else if(lAbscisse < dernierAbs){
			GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
			GLCD_DrawVLine((lAbscisse + LARGEUR_BOULE) , lOrdonne , HAUTEUR_BOULE);
			effacementJoueur = true;
		}

		//Effacement derri�re le vaisseau lorsqu'il se d�place en ordonne
		if(lOrdonne > dernierOrd){
			GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
			GLCD_DrawHLine(lAbscisse , (lOrdonne - 1) , HAUTEUR_BOULE);
			effacementJoueur = true;
		}else if(lOrdonne < dernierOrd){
			GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
			GLCD_DrawHLine(lAbscisse , (lOrdonne + HAUTEUR_BOULE) , HAUTEUR_BOULE);
			effacementJoueur = true;
		}
		
		
	}
}
