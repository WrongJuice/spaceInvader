#include "ext_globales.h"
#include "GLCD_Config.h"
//#include "ennemi.h"
		
struct Ennemi{
		int abscisse , ordonne , abcissePrecedent , ordonnePrecedent , angle;
		bool alive;
};
