/**
  ******************************************************************************************************************
  * @file    main.c 
  * @author  Alfred.G     IUT Informatique La Rochelle
  * @version v5
  * @date    16 Juin 2018
  * @brief   Projet Space Invader
  ******************************************************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <stm32f10x.h> // STM32F10x Library Definitions
#include "stm32f10x.h"                  /* STM32F10x.h definitions            */
#include "GLCD_Config.h"
#include "boule.h"
#include "ext_globales.h"
#include "globales.h"
#include <math.h>

#define UIE (1<<0) 
#define UIF (1<<0) //Flag d'interruption

int compteur[6]={0 , 0 , 0 , 0 , 0 , 0}; //Un compteur, �a peut toujours �tre utile

#define SETENA0 *(volatile unsigned long *)0xE000E100

/*----------------------------------------------------------------------------
  Etats
 *----------------------------------------------------------------------------*/
int  currentGameState , dernierAbs , dernierOrd;


/*----------------------------------------------------------------------------
  Timer
 *----------------------------------------------------------------------------*/
void cfgTimer1(void){
	RCC->APB2ENR |= (1 << 11);
	TIM1->PSC = 9; //On choisi un PSC � 9
	TIM1->ARR = 45000; //72/10=7.2Mhz = 7.2*10^6Hz/160 = 45000
	TIM1->DIER |= (1<<0);
	TIM1->CR1 |= 0x0001;
	SETENA0 |= (1<<25);
}


/*----------------------------------------------------------------------------
  Interruptions timer
 *----------------------------------------------------------------------------*/
void TIM1_UP_TIM10_IRQHandler (void){
 	if(TIM1->SR & UIF)
 	{
	  	TIM1->SR &= ~UIF; //Abaissement du flag d'interruption
	  //DEPLACEMENTS JOUEUR
		if (lAbscisse != (320 - LARGEUR_BOULE)) lAbscisse++;
	}
}

/*----------------------------------------------------------------------------
  Main Program
 *----------------------------------------------------------------------------*/
int main (void){
	effacementJoueur = true;
	dernierAbs = lAbscisse;
	dernierOrd = lOrdonne;
	lOrdonne = 110;
	lAbscisse = 0;
	GLCD_Initialize();                          /* Initialize graphical LCD display   */
 	GLCD_SetBackgroundColor(GLCD_COLOR_BLACK);
	GLCD_SetForegroundColor(GLCD_COLOR_RED);
	GLCD_ClearScreen();               /* Clear graphical LCD display        */
	GLCD_SetFont(&GLCD_Font_6x8);
	GLCD_FrameBufferAccess(true); // A faire avant appel de GLCD_DrawPixel et GLCD_ReadPixel pour supprimer
																// les limitations d'accès à la SRAM (uniquement nécessaire sur les anciennes
																// cartes sinon les fonctions GLCD_DrawPixel et GLCD_ReadPixel ne 
																// fonctionnent pas
	GLCD_DrawString(30 , 0 , "Projet Si - Alfred Gaillard | D2");
	GLCD_DrawHLine(0 , 8 , 320);
	GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
	
	cfgTimer1();

	while(1){
		
		GLCD_DrawBitmap(lAbscisse , lOrdonne , LARGEUR_BOULE , HAUTEUR_BOULE , (const unsigned char *)vaisseau);
		
		//Effacement derri�re le vaisseau lorsqu'il se d�place en abcisse
		if(lAbscisse > dernierAbs){
			GLCD_SetForegroundColor(GLCD_COLOR_BLACK);
			GLCD_DrawVLine(lAbscisse - 1 , lOrdonne , HAUTEUR_BOULE);
			effacementJoueur = true;
		}
	}
}
